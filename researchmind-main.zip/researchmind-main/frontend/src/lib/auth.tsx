import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api, clearToken, getToken, setToken } from './api'

type User = { id: string; email: string }

type AuthCtx = {
  user: User | null
  ready: boolean
}

const Ctx = createContext<AuthCtx | null>(null)

// Default guest credentials — auto-created on first run
const GUEST_EMAIL = 'guest@researchmind.local'
const GUEST_PASSWORD = 'researchmind-guest-2024'

async function autoLogin(setUser: (u: User) => void, setReady: (r: boolean) => void) {
  // Try existing token first
  const token = getToken()
  if (token) {
    try {
      const d = await api<{ user: User }>('/api/me')
      setUser(d.user)
      setReady(true)
      return
    } catch {
      clearToken()
    }
  }

  // Auto-login with guest account
  try {
    const d = await api<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: GUEST_EMAIL, password: GUEST_PASSWORD }),
    })
    setToken(d.token)
    setUser(d.user)
  } catch {
    // Guest account doesn't exist yet — register it
    try {
      const d = await api<{ token: string; user: User }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify({ email: GUEST_EMAIL, password: GUEST_PASSWORD }),
      })
      setToken(d.token)
      setUser(d.user)
    } catch {
      // Backend not reachable — will show connection error
    }
  }
  setReady(true)
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    autoLogin(setUser, setReady)
  }, [])

  const value = useMemo<AuthCtx>(
    () => ({
      user,
      ready,
    }),
    [user, ready],
  )

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useAuth() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('auth')
  return ctx
}
