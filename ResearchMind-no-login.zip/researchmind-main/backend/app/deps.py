from functools import lru_cache
from typing import Annotated

from fastapi import Depends, Header

from app.config import Settings, get_settings
from app.db.store import Store
from app.llm.factory import create_llm
from app.security import decode_token, hash_password


@lru_cache
def _store() -> Store:
    return Store(get_settings())


def get_store() -> Store:
    return _store()


def get_llm():
    return create_llm(get_settings())


# The login/register UI has been removed. Every request is now treated as a
# single local "guest" account that is created automatically on first use, so
# all existing per-user data (projects, sessions, etc.) keeps working
# unchanged without anyone having to sign in.
_GUEST_EMAIL = "guest@researchmind.local"


def get_current_user(
    store: Annotated[Store, Depends(get_store)],
    settings: Annotated[Settings, Depends(get_settings)],
    authorization: Annotated[str | None, Header()] = None,
) -> dict:
    # Back-compat: if an old client still sends a Bearer token, honor it.
    if authorization and authorization.lower().startswith("bearer "):
        payload = decode_token(authorization.split(" ", 1)[1], settings)
        if payload:
            user = store.get_user(payload["sub"])
            if user:
                return user

    user = store.get_user_by_email(_GUEST_EMAIL)
    if not user:
        user = store.create_user(_GUEST_EMAIL, hash_password(_GUEST_EMAIL))
    return user
