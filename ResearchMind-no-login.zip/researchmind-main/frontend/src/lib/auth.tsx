import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api } from './api'

type User = { id: string; email: string }

type AuthCtx = {
  user: User | null
  ready: boolean
}

const Ctx = createContext<AuthCtx | null>(null)

// There is no login/register flow anymore. The backend treats every request
// as a single local "guest" account (auto-created on first use), so the app
// just fetches that guest identity once on load and is ready immediately.
export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    api<{ user: User }>('/api/me')
      .then((d) => setUser(d.user))
      .catch(() => setUser({ id: 'guest', email: 'guest@researchmind.local' }))
      .finally(() => setReady(true))
  }, [])

  const value = useMemo<AuthCtx>(() => ({ user, ready }), [user, ready])

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useAuth() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('auth')
  return ctx
}
