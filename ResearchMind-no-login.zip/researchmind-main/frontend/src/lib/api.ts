const TOKEN = 'rm_token'

// In production, VITE_API_URL MUST be set (in Vercel: Settings -> Environment
// Variables) to your real deployed backend URL, e.g. https://your-backend.onrender.com
// In local development, leave it empty so Vite proxies /api to localhost:8000.
//
// IMPORTANT: there is intentionally NO hardcoded fallback URL here. A guessed
// fallback silently points the whole app at a URL that may not be your actual
// backend, which causes every request to fail with no useful error message
// (this was the cause of the "stuck on sign in" bug in production).
export const API_BASE = import.meta.env.VITE_API_URL || ''

if (import.meta.env.PROD && !import.meta.env.VITE_API_URL) {
  // Fails loudly in the browser console instead of silently hitting a dead URL.
  // eslint-disable-next-line no-console
  console.error(
    '[ResearchMind] VITE_API_URL is not set. Set it in your hosting provider\'s ' +
      'environment variables to your deployed backend URL, then redeploy.',
  )
}

export function getToken(): string | null {
  return localStorage.getItem(TOKEN)
}

export function setToken(token: string) {
  localStorage.setItem(TOKEN, token)
}

export function clearToken() {
  localStorage.removeItem(TOKEN)
}

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  if (import.meta.env.PROD && !API_BASE) {
    throw new Error(
      'The app is not configured with a backend URL (VITE_API_URL is missing). ' +
        'Set it in your hosting provider\'s environment variables and redeploy.',
    )
  }

  const headers = new Headers(init.headers)
  if (!headers.has('Content-Type') && init.body && !(init.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json')
  }
  const token = getToken()
  if (token) headers.set('Authorization', `Bearer ${token}`)
  const url = `${API_BASE}${path}`

  let res: Response
  try {
    res = await fetch(url, { ...init, headers })
  } catch {
    // fetch() throws a plain TypeError for network/DNS/CORS failures with no
    // detail, so translate it into something the user (and the sign-in form)
    // can actually show instead of failing silently.
    throw new Error(
      `Could not reach the server at ${API_BASE || '(no URL configured)'}. ` +
        'Check that the backend is deployed and running, and that VITE_API_URL is correct.',
    )
  }

  if (!res.ok) {
    let detail = res.statusText
    try {
      const j = await res.json()
      detail = j.detail || JSON.stringify(j)
    } catch {
      /* ignore */
    }
    throw new Error(typeof detail === 'string' ? detail : 'Request failed')
  }
  return res.json() as Promise<T>
}

// Helper for SSE streams — respects API_BASE
export function apiStreamUrl(path: string): string {
  return `${API_BASE}${path}`
}
