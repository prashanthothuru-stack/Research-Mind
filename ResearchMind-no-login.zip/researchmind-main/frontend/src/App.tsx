import { Route, Routes } from 'react-router-dom'
import { AuthProvider, useAuth } from './lib/auth'
import Landing from './pages/Landing'
import Shell from './pages/Shell'
import Dashboard from './pages/Dashboard'
import NewResearch from './pages/NewResearch'
import SessionPage from './pages/Session'
import SettingsPage from './pages/Settings'
import PaperMonitors from './pages/PaperMonitors'
import PublicSession from './pages/PublicSession'
import type { ReactNode } from 'react'

// No login is required anymore — everyone is automatically a "guest" user
// (see lib/auth.tsx). This just waits for that guest session to be fetched
// once before rendering the app, instead of gating access behind sign-in.
function Guard({ children }: { children: ReactNode }) {
  const { ready } = useAuth()
  if (!ready) return <div className="min-h-svh bg-ink p-10 text-mist">Loading…</div>
  return children
}

export default function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/share/:token" element={<PublicSession />} />
        <Route
          path="/app"
          element={
            <Guard>
              <Shell />
            </Guard>
          }
        >
          <Route index element={<Dashboard />} />
          <Route path="new" element={<NewResearch />} />
          <Route path="monitors" element={<PaperMonitors />} />
          <Route path="sessions/:id" element={<SessionPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
      </Routes>
    </AuthProvider>
  )
}
